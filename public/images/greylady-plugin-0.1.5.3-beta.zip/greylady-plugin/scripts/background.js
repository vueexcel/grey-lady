// chrome.browserAction.onClicked.addListener(
	
// 	function(tab) { 
		

// 		var bgPage = chrome.extension.getBackgroundPage();

// 		bgPage.closeGreylady();
// 	}


// );