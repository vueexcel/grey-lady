var debug = false;
var logging_level = 0;
var parsing_errors = [];
var listing_information = {};
var api_listing_information = {};
var zip_information = {};
var greylady_token = false;
var greylady_user_info = false;
var greylady_current_listing_id = false;
var greylady_open = false;
var greylady_newest_plugin_version = false;

var config = {
	grey_lady_base: "https://app.greyladyproject.com",
	grey_lady_url: "https://app.greyladyproject.com/api/secure",
	downpayment_precentage: 0.20,
	mortgage_interest_rate: 4.5,
	mortgage_term_years: 30,
	loss_to_vacancy: 0.1,
	operating_expense_ratio: 0.1,
	assumed_rent: {
		"02115" : {1: 1000, 2: 1500, 3: 2000, 4: 2500},
		"02108" : {1: 1000, 2: 1500, 3: 2000, 4: 2500, 6: 3000},
		"02118" : {1: 1000, 2: 1500, 3: 2000, 4: 2500, 6: 3000},
		"02114" : {1: 1000, 2: 1500, 3: 2000, 4: 2500, 6: 3000}
	}
}
