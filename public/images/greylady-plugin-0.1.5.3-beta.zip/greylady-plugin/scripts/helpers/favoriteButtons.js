function renderFavoriteButtons (listing_id_from_greylady = false) {

	// sometimes this function is called without a listing ID after clicking a favorites button
	// to easily re-render the correct state of the favorites buttons.
	if (!listing_id_from_greylady) {
		listing_id_from_greylady = greylady_current_listing_id;
	}

	var listing = api_listing_information;
	var html = '';

	favoriteZipInGreyLady = isZipFavorite(listing.details.location.zip);
	
	html += '<a type="button" class="btn btn-default" target=_blank href="' + config.grey_lady_base + '/scenario/run/' + listing.id + '">Scenario Runner</a>';
	
	if ( favoriteZipInGreyLady ) {
		html += '<a id="zip-remove-to-favorites" type="button" class="btn btn-default" data-zip-id="'+favoriteZipInGreyLady.id+'">Remove Zip</a>';
	} else {
		html += '<a id="zip-add-to-favorites" type="button" class="btn btn-default" data-zip-id="'+zip_information.details.id+'" data-zip="'+listing.details.location.zip+'">Save Zip</a>';
	}	
	

	favoriteListingInGreyLady = isListingFavorite(listing_id_from_greylady);
	if ( favoriteListingInGreyLady ) {
		html += '<a id="listing-remove-to-favorites" type="button" class="btn btn-default" href="#" data-listing-id="'+favoriteListingInGreyLady.id+'">Remove Listing</a>';
	} else {
		html += '<a id="listing-add-to-favorites" type="button" class="btn btn-default" href="#" data-listing-id="'+listing_id_from_greylady+'">Save Listing</a>';
	}

	document.getElementById('favorite-buttons').innerHTML = html;

	$('#zip-add-to-favorites').bind('click', function (event) {
		event.preventDefault();
		var zip = $(this).data();

		console.log(zip);

		saveZipAsFavorite(zip.zip, zip.zipId, function () {
			updateFavoriteButtons();
		});
  	});

  	$('#listing-add-to-favorites').bind('click', function (event) {
  		event.preventDefault();

  		var listing_id = $(this).data();
  		var full_address = listing.details.location.address + ' ' + listing.details.location.city + ' ' + listing.details.location.state;

  		saveListingAsFavorite(listing_id.listingId, full_address, function () {
			updateFavoriteButtons();
		});
  	});

	$('#zip-remove-to-favorites').bind('click', function (event) {
		event.preventDefault();
		var favorite_id = $(this).data();

		DeleteZipAsFavorite(favorite_id.zipId, function () {
			updateFavoriteButtons();
		});
  	});

  	$('#listing-remove-to-favorites').bind('click', function (event) {
  		event.preventDefault();

  		var favorite_id = $(this).data();

  		DeleteListingAsFavorite(favorite_id.listingId, function () {
  			updateFavoriteButtons();
  		});
  	});

	
}

// this will go get the current favorites list from the server and then update the 
// favorite buttons based on the response. It's called after a favorite button click.
function updateFavoriteButtons () {

	getUserInformation(function () {

		renderFavoriteButtons();

	});
}

function isListingFavorite (listing_id) {

	if (greylady_user_info && greylady_user_info.favorite_listings) {
	
		var listings = greylady_user_info.favorite_listings;

		for (var i = listings.length - 1; i >= 0; i--) {
			if (listing_id == listings[i].listing_id) {
				return listings[i];
			} 
		}	
		return false;	
	}	
	return false;	

}

function isZipFavorite (current_zip) {

	if (greylady_user_info && greylady_user_info.favorite_zips) {
	
		var zips = greylady_user_info.favorite_zips;

		for (var i = zips.length - 1; i >= 0; i--) {
			if (current_zip == zips[i].zip_code) {
				return zips[i];
			} 
		}	
		return false;	
	}	
	return false;	
}
