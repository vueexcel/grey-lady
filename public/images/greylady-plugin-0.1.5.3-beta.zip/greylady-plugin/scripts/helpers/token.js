function checkOrGetAPIKey (callback) {

	chrome.storage.local.get(["greylady_token"], function(items){

		if (items && items.greylady_token) {
			// we have the token, make it available for other functions to use. 

			greylady_token = items.greylady_token;

			getUserInformation(callback);

			// callback();

			return;

		} else {
			//we don't have a token. Need to go get one. 
			createSignInForm();		
		}
	    
	});

	return;

}

function getGreyLadyAppToken (email_address, password) {

	var token_url = 'https://app.greyladyproject.com/oauth/token';
	var user_information = {
		username: email_address,
		password: password,
		grant_type: 'password',
		client_id: 2,
		client_secret: 'sk0spJfEoPIFNUgY0pr1AokmvNOMuD8fi4zUKHCI'
	}

	$.post(token_url, user_information, function(data, textStatus, xhr) {

		debug('============== CORS DEBUGGING ================', 4);
		debug('Response Headers: ', 4);
		debug( xhr.getAllResponseHeaders(), 4 );
		debug('==============================================', 4);
		
		if (data.access_token) {

			saveAccessToken(data)

		} else {

			loginFailed(); 

		}

	});

}

function removeGreyLadyAppToken () {
	chrome.storage.local.remove(['greylady_token', 'greylady_token_type'], function(Items) {
		alert('you have been logged out');

		createSignInForm();
	});
}

function saveAccessToken (data) {
	
	var data_to_save = {
		greylady_token: data.access_token,
		greylady_token_type: data.token_type
	};

	chrome.storage.local.set(data_to_save, function(){
	   loginSuccess(); 
	});

}

function createSignInForm () {

	var sign_in_form_html = '';
	
	// sign_in_form_html += '<span>'+ listing_information.details.property_type + ' - </span>';
	sign_in_form_html += '<div id="SignUpFormContainer">';
	sign_in_form_html += '<div class="login-box">';
	sign_in_form_html += '<div class="login-logo">';
	sign_in_form_html += '<b>Grey</b>Lady';
	sign_in_form_html += '</div>';
	sign_in_form_html += '<div id="signInFailedMessage">Email or Password didnt work</div>';
	sign_in_form_html += '<div class="login-box-body">';
	sign_in_form_html += '<p class="login-box-msg">Sign in to start your session</p>';
	sign_in_form_html += '<form action="#" method="post">';
	sign_in_form_html += '<div class="form-group has-feedback">';
	sign_in_form_html += '<input id="signInemail" type="email" class="form-control" placeholder="Email">';
	sign_in_form_html += '</div>';
	sign_in_form_html += '<div class="form-group has-feedback">';
	sign_in_form_html += '<input id="signInpassword" type="password" class="form-control" placeholder="Password">';
	sign_in_form_html += '</div>';
	sign_in_form_html += '<div class="row">';
	sign_in_form_html += '<div class="col-xs-4">';
	sign_in_form_html += '<button id="signInButton" type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>';
	sign_in_form_html += '</div>';
	sign_in_form_html += '</div>';
	sign_in_form_html += '</form>';
	sign_in_form_html += '<a target=_blank href="https://app.greyladyproject.com/password/reset">I forgot my password</a><br>';
	sign_in_form_html += '</div>';
	sign_in_form_html += '</div>';

 
	document.getElementById('greyladycontainer').innerHTML += sign_in_form_html;	
	
	$('#signInButton').bind('click', function(event) {
		event.preventDefault();

		var email = $('#signInemail').val();
		var password = $('#signInpassword').val();

		// console.log(email);
		// console.log(password);

		getGreyLadyAppToken(email, password)

	});

}

function loginSuccess() {
	document.getElementById('SignUpFormContainer').remove();
}

function loginFailed() {
	// $('#signInFailedMessage').show().fade('slow');
}
