debug('Greylady loaded...........');

window.onload = function() {

	if ( isRealtor() || isZillow() ) {

		// really unfortunate - need to poll the url to see if it's on a pdp...
		// since zillow and realtor use javascript to build the pdps rather than opening a new page.
		setInterval(function () {

			switch ( shouldOpenGreyLady() ) {
				case 'open':
					debug('Opening Greylady!!', 10);
					onLoad();
				break;
				case 'close':
					debug('Closing Greylady!!', 10);
					closeGreylady();
				break;
				case 'nothing':
				default:
					debug('Doing nothing...', 10);
				break;
			}

		}, 3000);

	} else {

		// just redfin and trulia for now. Don't need to poll the url since they use static pages.
		onLoad();
	}
};


//this is the main function of the program. Needs to be refactored at somepoint.
function onLoad (pageHost = false) {

	//this inserts the UI into the existing tab. 
	load_container(function () {

		//this checks to see if the user is authenticated by checking google chrome sync storage for the token. If it's there
		//then this function makes it available in the greylady_token variable for it to be appended to requests in greyladydriver.
		checkOrGetAPIKey( function () {
			
			//this scrapes the page for all listing information available. It saves this data to 
			// "listing_information" which is a global variable set in config.js. This var is how 
			//most functions get access to the listing information. Very hacky for now..
			listing_information = get_listing_information_from_page();


			if ( !enoughListingInformation( listing_information ) ) {

				return false;

			}

			// this takes the listing information and trys to create a new listing. If it already exists,
			// Greylady will return the listing id. If it's new, then greylady will create it and then return
			// the listng id of the new listing. 
			createListing(listing_information, function () {

				if (isUpdateAvailable()) {
					return false;
				}

				//render the listing information in the user interface.
				//this information is a combination of what is taken from the page as well as 
				//information that comes back from the api. 
				renderAddress();
				renderBasicInformation();
				renderFinancials();
				renderJumpTo();
				
				//get zip code stats from the api and then render them on the page in the "zip"
				//box. 
				getZipInformation(api_listing_information.details.location.zip, function (response) {
			  		
			  		zip_information = response[0];
			  		
			  		debug('===============================');
			  		debug('Zip API Response:');
			  		debug(zip_information);
			  		debug('===============================');
			  		
			  		renderFavoriteButtons();
			  		renderZipStats();
			  	});
			});
			
			show_errors();
		});

	});
	
}