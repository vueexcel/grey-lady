function getListingDetails (callback) {

	var listing_id = greylady_current_listing_id;

	// console.log('getListingDetails...');
	// console.log(listing_id);
	
	getListingDetailsFromGreylady(listing_id, 'sell', function (response) {

		// console.log('getListingDetails... response:');
		// console.log(response);

		if (response && response.calculated_fields && response.calculated_fields[0]) {
			listing_information.calculated_fields = response.calculated_fields[0];
		}

		// console.log('is calculated field there?');
		// console.log(listing_information);

		callback();
	});

}

function createListing (listing_object_from_page, callback) {

	addListingtoGreylady(listing_object_from_page, function (response) {

		if ( response && response.api_response && response.api_response.cretedlistingItemResponse && response.api_response.cretedlistingItemResponse[0] ) {
			
			showSuccessMessage('Already in Greylady...');

			greylady_newest_plugin_version = response.version;
			api_listing_information = response.api_response.cretedlistingItemResponse[0];
			greylady_current_listing_id = response.api_response.cretedlistingItemResponse[0].id;

			debug('===================================',2);
			debug('Listing Object from API: ',2);
			debug(api_listing_information,2);
			debug('===================================',2);
			
		} else {
			// showSuccessMessage('Added to Greylady!');	
			// greylady_current_listing_id = response.id;

			debug('===================================',2);
			debug('There was an error, heres the response: ',2);
			debug(response,2);
			debug('===================================',2);
		}

		callback();

	});

}