function reportParsingErrorToGreylady () {

	var parsingErrorData = {};
	
	parsingErrorData.url = window.location.href;
	parsingErrorData.missingFields = JSON.stringify(listing_information);
	parsingErrorData.caughtErrors = parsing_errors.toString();

	reportParsingError ( parsingErrorData, function () {
		debug('Parsing Error Successfully Reported', 4);
	} );

}