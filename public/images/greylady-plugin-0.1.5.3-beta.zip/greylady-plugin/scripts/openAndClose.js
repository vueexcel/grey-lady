function load_container(do_this_next) {

	if (document.getElementById('grey-lady-container')) {

		$('#grey-lady-container').remove();
		create_container(do_this_next);

	} else {

		create_container(do_this_next);
	}
}



function create_container (do_this_next) {
	var css = document.createElement("style");
	css.type = "text/css";
	css.innerHTML = ".grey-lady-container { position: fixed; top: 0px; right: 0px; bottom: 0px; z-index: 999999999 !important;}";
	document.body.appendChild(css);



	var container = document.createElement('div');
	container.classList.add('grey-lady-container');
	container.id = 'grey-lady-container';
	container.innerHTML = '';

	document.body.insertBefore(container, document.body.lastChild);

	var html_url = chrome.extension.getURL("injected.html");
	// console.log(html_url);
	var xhr= new XMLHttpRequest();
	xhr.open('GET', html_url, true);

	// console.log(xhr);

	xhr.onreadystatechange= function() {
	    if (this.readyState!==4) return;
	    if (this.status!==200) return; // or whatever error handling you want
	    document.getElementById('grey-lady-container').innerHTML= this.responseText;
	    do_this_next();
	};
	xhr.send();
	greylady_open = true;
}

function closeGreylady () {
	debug('Greylady is being closed', 1);
	var html = '';
	html += '<div id="open-greylady" class="open-greylady" type="button" class="btn btn-default">Open <span>Grey</span>lady</div>';
	
	if($('#open-greylady').length == 0) {
		$("body").append(html);
	}
	
	$('#grey-lady-container').remove();
	// $('.grey-lady-container').html(html);
	// greylady_open = false;

	$('#open-greylady').bind('click', function (event) {

		debug('User has opened Greylady', 1);
		$('#open-greylady').remove();
		// greylady_open = true;
		onLoad();

	});

}