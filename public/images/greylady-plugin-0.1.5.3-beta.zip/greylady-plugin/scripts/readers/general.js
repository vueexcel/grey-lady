function get_listing_information_from_page () {

	debug(window.location.href);

	if(window.location.href.indexOf("redfin") > -1) {
		debug('using redfin reader...', 2);
		return get_listing_information_redfin();
    } else if ( window.location.href.indexOf("zillow") > -1) {
    	debug('using zillow reader...', 2);
    	return get_listing_information_zillow();
    } else if ( window.location.href.indexOf("trulia") > -1) {
    	debug('using trulia reader...', 2);
    	return get_listing_information_trulia();
    } else if ( window.location.href.indexOf("realtor") > -1) {
    	debug('using realtor reader...', 2);
    	return get_listing_information_realtor();
    } else {
    	debug('nothing, this shouldnt happen...', 2);
    	return false;
    }
}

function return_empty_object () {

	var listing_information_to_return = {};

	listing_information_to_return.details = {};
	listing_information_to_return.details.purchaseType = '';
	listing_information_to_return.details.propertyType = '';
	listing_information_to_return.details.beds = '';
	listing_information_to_return.details.baths = '';
	listing_information_to_return.details.price = '';
	listing_information_to_return.details.displayPrice = '';
	listing_information_to_return.details.LivingArea = '';
	listing_information_to_return.details.LivingAreaUnits = '';
	listing_information_to_return.details.LotSizeAcres = '';
	listing_information_to_return.details.LotSizeSquareFeet = '';
	listing_information_to_return.details.propertyTax = '';
	listing_information_to_return.details.propertyTaxFrequency = '';
	listing_information_to_return.details.AssociationFee = '';
	listing_information_to_return.details.AssociationFeeFrequency = '';
	listing_information_to_return.details.PublicRemarks = '';
	listing_information_to_return.details.YearBuilt = '';
	listing_information_to_return.details.MlsStatus = '';
	listing_information_to_return.details.ListAgentFirstName = '';
	listing_information_to_return.details.ListAgentLastName = '';
	listing_information_to_return.details.ListAgentPreferredPhone = '';
	listing_information_to_return.details.ListAgentPreferredEmail = '';
	listing_information_to_return.details.NumberOfUnits = '';

	listing_information_to_return.details.location = {};
	listing_information_to_return.details.location.address = '';
	listing_information_to_return.details.location.city = '';
	listing_information_to_return.details.location.zip = '';
	listing_information_to_return.details.location.state = '';
	listing_information_to_return.details.location.CountyOrParish = '';

	listing_information_to_return.units = [];

	listing_information_to_return.source = {};
	listing_information_to_return.source.source = '';
	listing_information_to_return.source.source_link = '';
	listing_information_to_return.source.source_pdp = '';

	return listing_information_to_return;
}

function tryToGetFromPage (javascript_to_execute, times_to_trim = 1) {

	try {

		var result = eval(javascript_to_execute);
		
		if (result) {
			
			for (var i = times_to_trim.length - 1; i >= 0; i--) {
				$.trim(result);
			}
			
			debug(result, 9);
			return result;
		} else {
			return '';
		}

	} catch ( error ) {

		log_parsing_error(error);

	}
}

function log_parsing_error( error ) {
	parsing_errors.push( error );
}

function show_errors() {
	if (debug && ( parsing_errors.length > 0) ) {
		debug('--------------------------------------------------------------------------------------------' );
		debug('---------------- There are ' + parsing_errors.length + ' Parsing Errors --------------------' );
		for (var i = parsing_errors.length - 1; i >= 0; i--) {
			debug(parsing_errors[i])
		}
		debug('--------------------------------------------------------------------------------------------' );
	} else {
		return false;
	}
}

function getSourceObject (source_name) {

	return {
		source: source_name,
		source_link: window.location.href,
		source_pdp: window.location.href
	};

}

function getNumberOfUnits (unit_array) {

	if ( Array.isArray( unit_array ) ) {
		return unit_array.length
	} else {
		return 0;
	}

}