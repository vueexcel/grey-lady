function getRealtorLocationObjectSale2 () {

	var address = tryToGetFromPage('$(\'span[itemprop="streetAddress"]\').eq(0).text()')
	var city = tryToGetFromPage('$(\'span[itemprop="addressLocality"]\').eq(0).text()')
	var zip = tryToGetFromPage('$(\'span[itemprop="postalCode"]\').eq(0).text()')
	var state = tryToGetFromPage('$(\'span[itemprop="addressRegion"]\').eq(0).text()')

	return {
		address: address,
		city: city,
		state: state,
		zip: zip
	}
}
function getRealtorLocationObjectSale () {
	var locationString = tryToGetFromPage('$("#aj-qv-sec-property-header").find("h2.address").text()');

	try {
		var address = $.trim(locationString.split(',')[0]);
		var city = $.trim(locationString.split(',')[1]);

		var state_zip = $.trim(locationString.split(',')[2]);
		var state = $.trim(state_zip.split('\n')[0]);
		var zip = $.trim(state_zip.split('\n')[1]);

		return {
			address: address,
			city: city,
			state: state,
			zip: zip
		}
	} catch ( error ) {
		
		log_parsing_error( error );
		return false;
	}
}
function getRealtorBathsSale () {

	debug('Realtor Reader, getRealtorBathsSale:', 5);

	var full_baths = tryToGetFromPage('$(\'li[data-label="property-meta-bath"]\').find("span").eq(0).text()');
	var half_baths = tryToGetFromPage('numeral($("#aj-qv-sec-property-header").find(".property-meta li").eq(1).find("span").eq(1).text()).value()');

	debug('full baths is: ' + full_baths + '', 5);
	debug('half baths is: ' + half_baths  + '', 5);

	return numeral( ( full_baths / 1 ) + (half_baths / 2) ).value();
}