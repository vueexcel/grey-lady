function getRealtorLocationObjectRent () {

	try {
		

		var address = tryToGetFromPage('$(\'.ldp-header-address span[itemprop="streetAddress"]\').text();');
		var city = tryToGetFromPage('$(\'.ldp-header-address span[itemprop="addressLocality"]\').text();');
		var state = tryToGetFromPage('$(\'.ldp-header-address span[itemprop="addressRegion"]\').text();');
		var zip = tryToGetFromPage('$(\'.ldp-header-address span[itemprop="postalCode"]\').text();');

		return {
			address: address,
			city: city,
			state: state,
			zip: zip
		}
	} catch ( error ) {
		
		log_parsing_error( error );
		return false;
	}
}
function getRealtorBathsRent () {

	var full_baths = tryToGetFromPage('$(\'#ldp-property-meta li[data-label="property-meta-baths"] .data-value\').eq(0).text()'); 	
	var half_baths = tryToGetFromPage('$(\'#ldp-property-meta li[data-label="property-meta-baths"] .data-value\').eq(1).text()'); 
	
	return numeral( ( full_baths / 1 ) + (half_baths / 2) ).value();
}