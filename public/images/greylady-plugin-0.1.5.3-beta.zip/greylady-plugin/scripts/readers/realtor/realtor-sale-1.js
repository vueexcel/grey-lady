function get_listing_information_realtor_sale_and_rent_1 () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );
	var purchaseType = getRealtorPurchaseType()

	listing_information_to_return.details.purchaseType = purchaseType;

	if (purchaseType == 'sell') {
		
		listing_information_to_return.details.location = getRealtorLocationObjectSale();
		listing_information_to_return.details.location.CountyOrParish = '';

		listing_information_to_return.details.propertyType = tryToGetFromPage("$('span.key:contains(\"Property Type\")').parent().find('span').eq(1).text()");
		var beds = tryToGetFromPage('numeral($("#aj-qv-sec-property-header").find(".property-meta li").eq(0).find("span").eq(0).text()).value()'); 
		var baths = getRealtorBathsSale();
		var sqft = tryToGetFromPage('numeral($("#aj-qv-sec-property-header").find(".property-meta li").eq(2).find("span").eq(0).text()).value()');
		var price = tryToGetFromPage('numeral($("#aj-qv-sec-property-header").find(".price span").text()).value()');
		var displayPrice = tryToGetFromPage('abbreviateCurrency($("#aj-qv-sec-property-header").find(".price span").text(), 0)');
		var description = tryToGetFromPage('$("#collapse-property-details").find(".js-details-load-more p.description").text()');

	} else {
		
		listing_information_to_return.details.location = getRealtorLocationObjectRent();
		listing_information_to_return.details.location.CountyOrParish = '';
		
		listing_information_to_return.details.propertyType = tryToGetFromPage('$(\'li[data-label="property-type"]\').find(".key-fact-data").eq(0).text()');
		
		var beds = tryToGetFromPage('numeral($(\'#ldp-property-meta li[data-label="property-meta-beds"] .data-value\').eq(0).text()).value()'); 
		var baths = getRealtorBathsRent();
		var sqft = tryToGetFromPage('numeral($(\'#ldp-property-meta li[data-label="property-meta-sqft"] .data-value\').eq(0).text()).value()'); 

		var price = tryToGetFromPage('numeral($(\'.ldp-header-price span[itemprop="price"]\').eq(0).text()).value()'); 
		var displayPrice = tryToGetFromPage('abbreviateCurrency($(\'.ldp-header-price span[itemprop="price"]\').eq(0).text(), 0)');

		var description = tryToGetFromPage('$("#ldp-detail-romance").eq(0).text()'); 

	}

	
	listing_information_to_return.details.beds = beds;
	listing_information_to_return.details.baths = baths;
	listing_information_to_return.details.LivingArea = sqft;
	listing_information_to_return.details.LivingAreaUnits = 'sqft';



	listing_information_to_return.details.price = price;
	listing_information_to_return.details.displayPrice = displayPrice;
	
	listing_information_to_return.details.LotSizeAcres = tryToGetFromPage('convertSquareFeetToAcres($("#aj-qv-sec-property-header").find(".property-meta li").eq(3).find("span").eq(0).text())');
	listing_information_to_return.details.LotSizeSquareFeet = tryToGetFromPage('numeral($("#aj-qv-sec-property-header").find(".property-meta li").eq(3).find("span").eq(0).text()).value()');
	
	listing_information_to_return.details.PublicRemarks = description;
	listing_information_to_return.details.YearBuilt = tryToGetFromPage("$('span.key:contains(\"Year Built\")').parent().find('span').eq(1).text()");
	listing_information_to_return.details.MlsStatus = $.trim(tryToGetFromPage("$('.property-status').find('span').eq(2).text()"));
	
	
	listing_information_to_return.source = getSourceObject('realtor');

	listing_information_to_return.details.propertyTax = ''; // needs a scroll to load
	listing_information_to_return.details.propertyTaxFrequency = ''; // needs a scroll to load
	listing_information_to_return.details.AssociationFee = '';
	listing_information_to_return.details.AssociationFeeFrequency = '';

	var agentName = getRealtorAgentName();
	listing_information_to_return.details.ListAgentFirstName = agentName.first;
	listing_information_to_return.details.ListAgentLastName = agentName.last;
	listing_information_to_return.details.ListAgentPreferredPhone = tryToGetFromPage('$.trim($("#aj-qv-sec-additional-info").find(".link-secondary span").eq(0).text())');
	listing_information_to_return.details.ListAgentPreferredEmail = ''; //doesn't provide

	
	listing_information_to_return.units = [];
	listing_information_to_return.details.NumberOfUnits = getNumberOfUnits( listing_information_to_return.units );
	

	return listing_information_to_return;

}

function getRealtorAgentName () {

	var agentName = $.trim(tryToGetFromPage('$("#aj-qv-sec-additional-info").find(".list-default.list-unstyled li a").eq(0).text()'));
	var agentArray = agentName.split(' ');

	if (agentArray.length == 3) {
		return {
			first: agentArray[0],
			middle: agentArray[1],
			last: agentArray[2]
		}

	} else if ( agentArray.length == 2 ) {
		return {
			first: agentArray[0],
			middle: '',
			last: agentArray[1]
		}

	} else {
		return {
			first: agentArray[0],
			middle: '',
			last: ''
		}
	}

	console.log(agentName);

}

function getRealtorPurchaseType () {
	
	var purchaseType = tryToGetFromPage('$(\'span[data-label="property-meta-status"]\').eq(0).text()');

	if ( (purchaseType.indexOf('sale') > -1) || (purchaseType.indexOf('Sale') > -1) ) {
		debug('Realtor reader thinks purchase type is sell', 5);
		return 'sell';
	} else if ( (purchaseType.indexOf('rent') > -1) || (purchaseType.indexOf('Rent') > -1) ) {
		debug('Realtor reader thinks purchase type is rent', 5);
		return 'rent';
	} else {
		debug('Realtor reader cannot find purchase type!!!!! Problem!!!!', 5);
		return '';
	}
}