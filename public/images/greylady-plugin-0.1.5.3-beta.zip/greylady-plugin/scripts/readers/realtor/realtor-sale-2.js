function get_listing_information_realtor_sale_2 () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );
	listing_information_to_return.source = getSourceObject('realtor');

	var purchaseType = getRealtorPurchaseType()

	listing_information_to_return.details.purchaseType = purchaseType;
	listing_information_to_return.details.location = getRealtorLocationObjectSale2();
	listing_information_to_return.details.propertyType = tryToGetFromPage('$(\'li[data-label="property-type"]\').find("div").eq(1).text()');

	listing_information_to_return.details.beds = tryToGetFromPage('$(\'li[data-label="property-meta-beds"]\').find("span").eq(0).text()');
	
	listing_information_to_return.details.baths = realtorSale2Baths(); 

	listing_information_to_return.details.LivingArea = tryToGetFromPage('numeral($(\'li[data-label="property-meta-sqft"]\').find("span").eq(0).text()).value()');
	listing_information_to_return.details.LivingAreaUnits = 'sqft';

	var price =tryToGetFromPage("numeral($('.ldp-header-price').find('span').eq(0).text()).value()");
	listing_information_to_return.details.price = price;
	listing_information_to_return.details.displayPrice = abbreviateCurrency(price, 2);

	listing_information_to_return.details.PublicRemarks = tryToGetFromPage('$(".details-more-placeholder").find("p").eq(0).text()');;


	return listing_information_to_return;

}

function realtorSale2Baths () {

	var full_baths = tryToGetFromPage('$(\'li[data-label="property-meta-baths"]\').find("span.property-half-baths").eq(0).text()');
	var half_baths = tryToGetFromPage('$(\'li[data-label="property-meta-baths"]\').find("span.property-half-baths").eq(1).text()');

	var baths_with_half_baths = numeral( ( full_baths / 1 ) + (half_baths / 2) ).value();

	// if there aren't half baths on the page then the dom structure changes. 
	if (baths_with_half_baths !== 0) {
		return baths_with_half_baths;	
	} else {
		
		var full_baths = tryToGetFromPage('$(\'li[data-label="property-meta-bath"]\').find(".data-value").eq(0).text()');
		return full_baths;
	}

}

