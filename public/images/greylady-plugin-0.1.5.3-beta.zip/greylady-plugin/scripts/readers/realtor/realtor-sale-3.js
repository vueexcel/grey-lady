function get_listing_information_realtor_sale_3 () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );
	listing_information_to_return.source = getSourceObject('realtor');

	var purchaseType = 'sell';

	listing_information_to_return.details.purchaseType = purchaseType;
	listing_information_to_return.details.location = getRealtorLocationObjectSale2();
	listing_information_to_return.details.propertyType = tryToGetFromPage('$(\'li[data-label="property-type"]\').find("div").eq(1).text()');

	listing_information_to_return.details.beds = tryToGetFromPage('$(\'li[data-label="property-meta-beds"]\').find("span").eq(0).text()');
	listing_information_to_return.details.baths = tryToGetFromPage('$(\'li[data-label="property-meta-baths"]\').find("span").eq(0).text()');
	listing_information_to_return.details.LivingArea = tryToGetFromPage('numeral($(\'li[data-label="property-meta-sqft"]\').find("span").eq(0).text()).value()');
	listing_information_to_return.details.LivingAreaUnits = 'sqft';

	var price =tryToGetFromPage("numeral($('span[itemprop=\"price\"]').text()).value()");
	listing_information_to_return.details.price = price;
	listing_information_to_return.details.displayPrice = abbreviateCurrency(price, 2);

	listing_information_to_return.details.PublicRemarks = tryToGetFromPage('$(".details-more-placeholder").find("p").eq(0).text()');;


	return listing_information_to_return;

}