function getRealtorReaderVersion () {

	//not sure of these right now. I'm going to leave them blank and then
	//remove them later if the readers aren't needed any more.
	var element_for_sale = "";
	var element_for_rent = "";

	var element_for_sale_2 = tryToGetFromPage('$(\'span[data-label="property-meta-status"]\').eq(0).text()');
	var element_for_rent_2 = tryToGetFromPage('$(\'span[data-label="property-meta-status"]\').eq(0).text()');
	var element_for_sale_3 = tryToGetFromPage('$(\'div.property-status\').find("span").eq(1).text()');
	var element_for_sale_4 = tryToGetFromPage('$(\'div.property-status\').find("span").eq(1).text()');
	

	if ( tryToGetFromPage(element_for_sale) ) {
		return 'sale_1';
	} else if ( tryToGetFromPage(element_for_rent) ) {
		return 'rent_1';
	} else if ( element_for_sale_2.indexOf('Sale') > -1) {
		return 'sale_2';
	} else if ( element_for_sale_3.indexOf('Sale') > -1) {
		return 'sale_3';
	} else if ( element_for_rent_2.indexOf('Rent') > -1 ) {
		return 'rent_2';
	} else if ( element_for_sale_2.indexOf('Off Market') > -1 ) {
		return 'sale_3';
	} else {
		return 'none';
	}
}

function get_listing_information_realtor () {

	var listing_information_to_return = {};

	switch ( getRealtorReaderVersion() ) {
		case 'sale_1':
			debug('Using Realtor sale_1 reader', 4);
			return get_listing_information_realtor_sale_and_rent_1();
		break;
		case 'rent_1':
			debug('Using Realtor rent_1 reader', 4);
			return get_listing_information_realtor_sale_and_rent_1();
		break;
		case 'sale_2':
			debug('Using Realtor sale_2 reader', 4);
			return get_listing_information_realtor_sale_2();
		break;
		case 'sale_3':
			debug('Using Realtor sale_3 reader', 4);
			return get_listing_information_realtor_sale_3();
		break;
		case 'rent_2':
			debug('Using Realtor rent_2 reader', 4);
			return get_listing_information_realtor_rent_2();
		break;
		case 'none':
		default:
			debug('No Realtor reader found... need to create a new one', 4);
			return false;
		break;
	}

}