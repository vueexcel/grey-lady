function get_listing_information_redfin () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );

	listing_information_to_return.details.propertyType = tryToGetFromPage("$('span.header:contains(\"Property Type\")').parent().find('span').eq(1).text()");
	listing_information_to_return.details.purchaseType = getRedfinPropertyType();

	listing_information_to_return.details.location.address = tryToGetFromPage('document.querySelector(".street-address").innerHTML');
	listing_information_to_return.details.location.city = tryToGetFromPage('document.querySelector(".locality").innerHTML.replace(/<!--(.*?)-->/g, "").replace(",", "")'); //redfin inserts random commas and comments in.
	listing_information_to_return.details.location.zip = tryToGetFromPage('document.querySelector(".postal-code").innerHTML');
	listing_information_to_return.details.location.state = tryToGetFromPage('document.querySelector(".region").innerHTML');
	listing_information_to_return.details.location.CountyOrParish = tryToGetFromPage("$('span.header:contains(\"County\")').parent().find('a').text()");

	listing_information_to_return.details.price = tryToGetFromPage('numeral(document.querySelectorAll(".statsValue div span")[1].innerHTML.replace(/,/g, "")).value()');
	listing_information_to_return.details.displayPrice = tryToGetFromPage('document.querySelectorAll(".statsValue div span")[1].innerHTML');
	listing_information_to_return.details.beds = tryToGetFromPage('document.querySelectorAll(".info-block")[1].querySelector(".statsValue").innerHTML');
	listing_information_to_return.details.baths = tryToGetFromPage('document.querySelectorAll(".info-block")[2].querySelector(".statsValue").innerHTML');
	listing_information_to_return.details.LivingArea = tryToGetFromPage('numeral(document.querySelectorAll(".info-block")[3].querySelector(".statsValue").innerHTML).value()');
	listing_information_to_return.details.LivingAreaUnits = 'sqft';
	listing_information_to_return.details.YearBuilt = tryToGetFromPage("numeral($('span.label:contains(\"Built:\")').parent().find('span').eq(1).text()).value()");	
	
	var lot_area_sqft = tryToGetFromPage("numeral($('span.header:contains(\"Lot Size\")').parent().find('span').eq(1).text().split(' ')[0]).value()");
	listing_information_to_return.details.LotSizeSquareFeet = lot_area_sqft;
	listing_information_to_return.details.LotSizeAcres = convertSquareFeetToAcres(lot_area_sqft);
	
	listing_information_to_return.details.PublicRemarks = tryToGetFromPage('document.querySelectorAll(".sectionContent")[0].querySelectorAll(".remarks")[0].querySelector("span").innerHTML');
	listing_information_to_return.details.MlsStatus = tryToGetFromPage('$("#overview-scroll").find(".DefinitionFlyout.definition-flyout-container.react.inline-block span.DefinitionFlyoutLink.inline-block.underline.clickable").text()');

	// listing_information_to_return.source.source = 'redfin';
	// listing_information_to_return.source.source_link = window.location.href;
	// listing_information_to_return.source.source_pdp = window.location.href;

	listing_information_to_return.source = getSourceObject('redfin');	

	listing_information_to_return.details.ListAgentFirstName = tryToGetFromPage('$("#house-info").find(".agent-basic-details span span").eq(0).text().split(\' \')[0]');
	listing_information_to_return.details.ListAgentLastName = tryToGetFromPage('$("#house-info").find(".agent-basic-details span span").eq(0).text().split(\' \')[1]');
	listing_information_to_return.details.ListAgentPreferredPhone = ''; // redfin doesn't provide
	listing_information_to_return.details.ListAgentPreferredEmail = ''; // redfin doesn't provide

	listing_information_to_return.details.propertyTax = tryToGetFromPage("numeral($('h4.title:contains(\"Tax Information\")').parent().find('span').eq(1).text()).value() / 12");
	listing_information_to_return.details.propertyTaxFrequency = 'monthly';

	listing_information_to_return.details.AssociationFee = tryToGetFromPage("numeral($('span.header:contains(\"HOA Dues\")').parent().find('span').eq(1).text().split('/')[0]).value()");
	listing_information_to_return.details.AssociationFeeFrequency = 'monthly';

	// listing_information_to_return.details.community = tryToGetFromPage('document.querySelectorAll(".keyDetailsList")[0].querySelectorAll("span")[3].innerHTML');	
	// listing_information_to_return.details.mls_number = tryToGetFromPage('document.querySelectorAll(".keyDetailsList")[0].querySelectorAll("span")[7].innerHTML');

	//unit information
	listing_information_to_return.units = [];
	listing_information_to_return.units = getRedfinUnitInformation();
	listing_information_to_return.details.NumberOfUnits = '';

	return listing_information_to_return;

}

function getRedfinUnitInformation () {

	var units = [];	
	var is_multi_family_on_the_page = $('h4:contains("Multi-Family Information")');

	// length comes back 0 if jquery didn't find anything. 
	if (is_multi_family_on_the_page.length) {

		var list_of_potential_unit_info = is_multi_family_on_the_page.closest('.super-group-content').find('.amenity-group');
		var unit_number = 1;
		for (var i = list_of_potential_unit_info.length - 1; i >= 0; i--) {
			
			//make sure you only add items to the units array that actually are units. 
			if ($(list_of_potential_unit_info[i]).find('.title').text().indexOf('Unit') != -1) {

				units[unit_number] = {};
				units[unit_number].levels = $(list_of_potential_unit_info[i]).find('span:contains("Levels")').find('span').text();
				units[unit_number].floors = $(list_of_potential_unit_info[i]).find('span:contains("Floors")').find('span').text();
				units[unit_number].rooms = $(list_of_potential_unit_info[i]).find('span:contains("Rooms")').find('span').text();
				units[unit_number].beds = $(list_of_potential_unit_info[i]).find('span:contains("Bedrooms")').find('span').text();
				units[unit_number].baths = $(list_of_potential_unit_info[i]).find('span:contains("Rooms")').find('span').text();
				units[unit_number].rent = numeral($(list_of_potential_unit_info[i]).find('span:contains("Rent")').find('span').text()).value();

				unit_number++;
			}

		}
	}

	return units;
}

function getRedfinPropertyType () {
	var is_for_sale = tryToGetFromPage('$("#overview-scroll").find(".bottom div.property.for-sale")');

	if (is_for_sale) {
		return 'sell';
	} else {
		return 'rent'
	}
}