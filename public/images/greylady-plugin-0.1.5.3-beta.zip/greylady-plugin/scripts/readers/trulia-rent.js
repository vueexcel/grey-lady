function getTruliaRentLocationObject () {

	try {
		var address = $.trim(tryToGetFromPage('$("#propertySummary").find("#address span").eq(0).text()'));

		var city_state_zip = $.trim(tryToGetFromPage('$("#propertySummary").find("#address span").eq(1).text()'));
		
		city_state_zip = city_state_zip.split(',');
		var city = $.trim(city_state_zip[0]);
		var state = city_state_zip[1].split(' ')[1];
		var zip = $.trim(city_state_zip[1].split(' ')[2]);

		return {
			address: address,
			city: city,
			state: state,
			zip: zip
		}
	} catch ( error ) {
		
		log_parsing_error( error );
		return false;
	}
}


function getTruliaBedsBathsSqftLotTypeRent () {
	
	try {
		var propertyType = '';
		var beds = '';
		var baths = '';
		var LivingArea = '';

		var beds_baths_sqft_lot_type = tryToGetFromPage('$("#property_features").find(" li")');

		propertyType = $(beds_baths_sqft_lot_type).eq(3).text();

		//fucking apartment buildings have ranges...
		var beds_from_page = $(beds_baths_sqft_lot_type).eq(0).text().split(' ')[0];
		beds = getLowerEndOfRangeTrulia( beds_from_page );

		//fucking apartment buildings have ranges...
		var baths_from_page = $(beds_baths_sqft_lot_type).eq(1).text().split(' ')[0];
		baths = getLowerEndOfRangeTrulia( baths_from_page );


		//fucking apartment buildings have ranges...
		var living_area_from_page = $(beds_baths_sqft_lot_type).eq(2).text().split(' ')[0];
		LivingArea = getLowerEndOfRangeTrulia( living_area_from_page );


		return {
			propertyType: propertyType,
			beds: beds,
			baths: baths,
			LivingArea: LivingArea
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			propertyType: propertyType,
			beds: beds,
			baths: baths,
			LivingArea: LivingArea
		}
	}
}


function getTruliaAgentObjectRent () {

	try {
		var firstName = '';
		var lastName = '';
		var phone = '';
		var email = '';

		var jquery_agent_section = $('.contactDetailsInfo').eq(0).parent().find(".contactDetailsStats");
		
		var fullName = $('.contactDetailsInfo').eq(0).parent().find(".contactDetailsStats").eq(0).text();

		firstName = fullName.split(' ')[0];
		lastName = fullName.split(' ')[1];

		phone = $.trim($('.contactDetailsInfo').eq(0).parent().find(".contactDetailsLink span").eq(0).text());

		return {
			first: firstName,
			last: lastName,
			phone: phone,
			email: email
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			first: '',
			last: '',
			phone: '',
			email: ''
		}
	}

}

function getLowerEndOfRangeTrulia (possible_range) {

	var lower_end_of_range = false; 

	if (possible_range.indexOf('-' > -1)) {
			lower_end_of_range = numeral(possible_range.split('-')[0]).value();
		} else {
			lower_end_of_range = numeral(possible_range).value();	
		}

	return lower_end_of_range;
}


function getTruliaRent() {

	try {
		var rent = '';

		rent = tryToGetFromPage('$("#propertySummary").find(".mvn span.h3").text()');

		rent = getLowerEndOfRangeTrulia(rent)

		return rent

	} catch ( error ) {

		log_parsing_error(error);
		return rent
	}
}