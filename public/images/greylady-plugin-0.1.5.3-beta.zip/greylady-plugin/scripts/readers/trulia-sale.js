function getTruliaSellLocationObject () {

	try {
		var address = $.trim(tryToGetFromPage('$("#propertySummary").find(".h3.defaultLineHeight div.pan.man.defaultLineHeight").text()'));

		var city_state_zip = tryToGetFromPage('$("#propertySummary").find(".h3.defaultLineHeight span.h6.typeWeightNormal.pts.typeLowlight.paXxsHidden.maXxsHidden").text()');
		
		city_state_zip = city_state_zip.split(',');
		var city = $.trim(city_state_zip[0]);
		var state = city_state_zip[1].split(' ')[1];
		var zip = $.trim(city_state_zip[1].split(' ')[2]);

		return {
			address: address,
			city: city,
			state: state,
			zip: zip
		}
	} catch ( error ) {
		
		log_parsing_error( error );
		return false;
	}
}

function getTruliaBedsBathsSqftLotTypeSale () {
	
	try {
		var propertyType = '';
		var beds = '';
		var baths = '';
		var LivingArea = '';

		var beds_baths_sqft_lot_type = tryToGetFromPage('$("#propertySummary").find(".listInline.Bulleted.man.pts.ptXxsHidden.pbsXxsVisible li")');

		propertyType = $(beds_baths_sqft_lot_type).eq(4).text();
		beds = numeral($(beds_baths_sqft_lot_type).eq(0).text().split(' ')[0]).value();
		baths = numeral($(beds_baths_sqft_lot_type).eq(1).text().split(' ')[0]).value();
		LivingArea = numeral($(beds_baths_sqft_lot_type).eq(2).text().split(' ')[0]).value();

		return {
			propertyType: propertyType,
			beds: beds,
			baths: baths,
			LivingArea: LivingArea
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			propertyType: propertyType,
			beds: beds,
			baths: baths,
			LivingArea: LivingArea
		}
	}
}

function getTruliaAgentObjectSale () {

	try {
		var firstName = '';
		var lastName = '';
		var phone = '';
		var email = '';

		var jquery_agent_section = $('h3:contains(\"Listing provided\")').parent().find("p");
		
		var fullName = jquery_agent_section.eq(0).text();
		firstName = fullName.split(' ')[0];
		lastName = fullName.split(' ')[1];

		phone = $.trim(jquery_agent_section.eq(1).text().split(':')[1]);

		return {
			first: firstName,
			last: lastName,
			phone: phone,
			email: email
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			first: '',
			last: '',
			phone: '',
			email: ''
		}
	}

}