function get_listing_information_trulia () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );

	listing_information_to_return.source = getSourceObject('trulia');

	var purchaseType = getTruliaPurchaseType();
	listing_information_to_return.details.purchaseType = purchaseType;
	listing_information_to_return.details.propertyType = tryToGetFromPage("$('div.status').eq(0).text()");
	

	if (purchaseType == 'sell') {	

		listing_information_to_return.details.location = getTruliaSellLocationObject();	
		listing_information_to_return.details.location.CountyOrParish = '';

		//For sale listings have a slightly different dom structure then for rent
		//this will pass back the same parsed object though, and it's assigned to the listing
		//object below
		var beds_baths_sqft_lot_type = getTruliaBedsBathsSqftLotTypeSale();

		//same thign with agent contact information
		var agentObject = getTruliaAgentObjectSale()

		//and price...
		var price = tryToGetFromPage('numeral($("#propertySummary").find(".mvn span.h3").text()).value()');

	} else {

		listing_information_to_return.details.location = getTruliaRentLocationObject();
		listing_information_to_return.details.location.CountyOrParish = '';

		//For sale listings have a slightly different dom structure then for rent
		//this will pass back the same parsed object though, and it's assigned to the listing
		//object below
		var beds_baths_sqft_lot_type = getTruliaBedsBathsSqftLotTypeRent();

		//same thign with agent contact information
		var agentObject = getTruliaAgentObjectRent()

		//rent for apartment buildings can have ranges, need a function to handle that shit. 
		var price = getTruliaRent();

	}

	listing_information_to_return.details.propertyType = beds_baths_sqft_lot_type.propertyType
	listing_information_to_return.details.beds = beds_baths_sqft_lot_type.beds
	listing_information_to_return.details.baths = beds_baths_sqft_lot_type.baths
	listing_information_to_return.details.LivingArea = beds_baths_sqft_lot_type.LivingArea
	listing_information_to_return.details.LivingAreaUnits = 'sqft';

	var lotSizeSqft = $(beds_baths_sqft_lot_type).eq(3).text().split(' ')[0]
	listing_information_to_return.details.LotSizeSquareFeet = lotSizeSqft;
	listing_information_to_return.details.LotSizeAcres = convertSquareFeetToAcres(lotSizeSqft);
	


	listing_information_to_return.details.PublicRemarks = $.trim(tryToGetFromPage('$("#propertyDescription").text()'));

	
	listing_information_to_return.details.price = price; 
	listing_information_to_return.details.displayPrice = formatCurrency( price );
	
	listing_information_to_return.details.YearBuilt = tryToGetFromPage("numeral($.trim($('li:contains(\"Built in\")').text()).split(' ')[2]).value()");

	
	listing_information_to_return.details.ListAgentFirstName = agentObject.first;
	listing_information_to_return.details.ListAgentLastName = agentObject.last;
	listing_information_to_return.details.ListAgentPreferredPhone = agentObject.phone;
	listing_information_to_return.details.ListAgentPreferredEmail = agentObject.email;

	listing_information_to_return.details.propertyTax = tryToGetFromPage('(numeral($(".payment-breakdown__legendAmount___2gWAl").eq(1).text()).value() * -1)');
	listing_information_to_return.details.propertyTaxFrequency = 'monthly';


	listing_information_to_return.details.AssociationFee = tryToGetFromPage("numeral($.trim($('li:contains(\"HOA\")').text()).split('/')[0]).value()");
	listing_information_to_return.details.AssociationFeeFrequency = 'monthly';	


	listing_information_to_return.details.MlsStatus = '';
	listing_information_to_return.units = [];
	listing_information_to_return.details.NumberOfUnits = getNumberOfUnits( listing_information_to_return.units );


	return listing_information_to_return;
}




function getTruliaPurchaseType () {

	var purchaseType = $.trim(tryToGetFromPage('$(".man").find(".typeCaps").text()'));

	debug(purchaseType,3);

	if ( purchaseType.indexOf("Rent") > -1) {
		return "rent";
	} else {
		return "sell";
	}	
}