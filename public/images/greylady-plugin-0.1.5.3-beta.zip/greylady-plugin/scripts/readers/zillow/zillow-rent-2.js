function get_listing_information_zillow_rent_2 () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );

	listing_information_to_return.source = getSourceObject('zillow');
	listing_information_to_return.details.purchaseType = 'rent';
	listing_information_to_return.details.propertyType = tryToGetFromPage("$('.ds-home-fact-label:contains(\"Type\")').parent().find('span').eq(1).text()");

	//location
	listing_information_to_return.details.location = getZillowLocationObjectSale_v2();
	listing_information_to_return.details.location.CountyOrParish = '';


	//beds, baths and livingArea, year build
	listing_information_to_return.details.beds = tryToGetFromPage('numeral($(".ds-bed-bath-living-area").eq(0).find("span").eq(0).text()).value()');
	listing_information_to_return.details.baths = tryToGetFromPage('numeral($(".ds-bed-bath-living-area").eq(1).find("span").eq(0).text()).value()');
	listing_information_to_return.details.LivingArea = tryToGetFromPage('numeral($(".ds-bed-bath-living-area").eq(2).find("span").eq(0).text()).value()');
	listing_information_to_return.details.LivingAreaUnits = 'sqft';
	listing_information_to_return.details.YearBuilt = tryToGetFromPage("numeral($('.ds-home-fact-label:contains(\"Year Built\")').parent().find('span').eq(1).text()).value()");
	listing_information_to_return.details.PublicRemarks = tryToGetFromPage('$(".character-count-truncated").text()');

	//price in it's various forms.
	var price = tryToGetFromPage('numeral($(".ds-price").find("span.ds-value").eq(0).text()).value()');
	listing_information_to_return.details.price = price;
	listing_information_to_return.details.displayPrice = formatCurrency(price, 0);

	var lot_in_sqft = tryToGetFromPage("numeral($('.ds-home-fact-label:contains(\"Lot\")').parent().find('span').eq(1).text()).value()");
	listing_information_to_return.details.LotSizeSquareFeet = lot_in_sqft;
	listing_information_to_return.details.LotSizeAcres = convertSquareFeetToAcres(lot_in_sqft);

	listing_information_to_return.details.propertyTax = tryToGetFromPage("numeral($('span:contains(\"Property taxes\")').parent().find('span').eq(1).text()).value() * 12");
	listing_information_to_return.details.propertyTaxFrequency = 'annual';

	var agentObject = getZillowAgentObjectSale_v2()
	listing_information_to_return.details.ListAgentFirstName = agentObject.first;
	listing_information_to_return.details.ListAgentLastName = agentObject.last;
	listing_information_to_return.details.ListAgentPreferredPhone = agentObject.phone;
	listing_information_to_return.details.ListAgentPreferredEmail = agentObject.email;

	listing_information_to_return.details.AssociationFee = tryToGetFromPage("numeral($('.ds-home-fact-label:contains(\"Hoa\")').parent().find('span').eq(1).text()).value()");
	listing_information_to_return.details.AssociationFeeFrequency = 'month';

	return listing_information_to_return;

}