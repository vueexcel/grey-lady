function get_listing_information_zillow_sale_and_rent () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );

	var purchaseType = getZillowPurchaseType();
	listing_information_to_return.details.purchaseType = purchaseType;
	listing_information_to_return.details.propertyType = tryToGetFromPage("$('div.status').eq(0).text()");
	listing_information_to_return.source = getSourceObject('zillow');	

	if (purchaseType == 'sell') {

		listing_information_to_return.details.location = getZillowLocationObjectSale();
		listing_information_to_return.details.location.CountyOrParish = '';

		var beds_baths_sqft = getZillowBedsBathSqftSale();
		var price = tryToGetFromPage('numeral($(".price").find("span").eq(0).text()).value()')

		listing_information_to_return.details.YearBuilt = tryToGetFromPage("numeral($('div.fact-value:contains(\"Built in\")').text().split(' ')[2]).value()");
		listing_information_to_return.details.PublicRemarks = tryToGetFromPage("$('#home-description-container').eq(0).text()");;

	} else {

		listing_information_to_return.details.location = getZillowLocationObjectRent();
		listing_information_to_return.details.location.CountyOrParish = '';

		var beds_baths_sqft = getZillowBedsBathSqftRent();
		var price = tryToGetFromPage('numeral($(".estimates .home-summary-row").eq(1).text()).value()')

		listing_information_to_return.details.YearBuilt = tryToGetFromPage("numeral($('ul.hdp-fact-list li:contains(\"Built in\")').text().split(' ')[2]).value()");
		listing_information_to_return.details.PublicRemarks = tryToGetFromPage("$('.hdp-header-description .zsg-content-item').eq(0).text()");;

	}

	
	listing_information_to_return.details.beds = beds_baths_sqft.beds;
	listing_information_to_return.details.baths = beds_baths_sqft.baths;
	listing_information_to_return.details.LivingArea = beds_baths_sqft.sqft;
	listing_information_to_return.details.LivingAreaUnits = 'sqft';
	
	listing_information_to_return.details.price = price;
	listing_information_to_return.details.displayPrice = formatCurrency(price, 0);
	
	var lot_in_sqft = tryToGetFromPage("numeral($('div.fact-label:contains(\"Lot\")').parent().find('div').eq(1).text().split(' ')[1]).value()");
	listing_information_to_return.details.LotSizeSquareFeet = lot_in_sqft;
	listing_information_to_return.details.LotSizeAcres = convertSquareFeetToAcres(lot_in_sqft);
	
	listing_information_to_return.details.propertyTax = tryToGetFromPage("numeral($('div.category-name:contains(\"Taxes\")').parent().find('div.fact-value').eq(0).text()).value()");
	listing_information_to_return.details.propertyTaxFrequency = 'annual';
	
	
	var agentObject = getZillowAgentObjectSale()
	listing_information_to_return.details.ListAgentFirstName = agentObject.first;
	listing_information_to_return.details.ListAgentLastName = agentObject.last;
	listing_information_to_return.details.ListAgentPreferredPhone = agentObject.phone;
	listing_information_to_return.details.ListAgentPreferredEmail = agentObject.email;
	
	listing_information_to_return.details.AssociationFee = tryToGetFromPage("numeral($('div.category-name:contains(\"HOA\")').parent().find('div.fact-value').eq(0).text()).value()");;
	listing_information_to_return.details.AssociationFeeFrequency = 'month';
	
	listing_information_to_return.units = [];
	listing_information_to_return.details.NumberOfUnits = getNumberOfUnits( listing_information_to_return.units );

	listing_information_to_return.details.MlsStatus = '';
	
	return listing_information_to_return;

}
function getZillowPurchaseType () {
	var purchaseTypeForSale = tryToGetFromPage("$('.home-details-price-area .status').text()");
	var purchaseTypeForRent = tryToGetFromPage("$('.for-rent-row').text()");

	if ( purchaseTypeForSale.indexOf('For Sale') > -1 ) {
		return 'sell';
	} else if ( purchaseTypeForRent.indexOf('For Rent') > -1 ) {
		return 'rent';
	} else {
		debug('Zillow: not finding purchaseType Correctly. This shouldnt happen', 3);
		return false;
	}
}