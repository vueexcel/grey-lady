function getZillowLocationObjectRent () {
	try {

		var address = tryToGetFromPage('$.trim($(".zsg-content-header.addr h1.notranslate").contents().get(0).nodeValue)');
		var city_state_zip = tryToGetFromPage('$(".zsg-content-header.addr .addr_city").text()');
		
		var city = city_state_zip.split(',')[0];
		var state_zip = $.trim(city_state_zip.split(',')[1]);
		var state = state_zip.split(' ')[0];
		var zip = state_zip.split(' ')[1];

		return {
			address: address,
			city: city,
			state: state,
			zip: zip
		}

	} catch ( error ) {

		log_parsing_error(error);
		return false;
	}
}
function getZillowBedsBathSqftRent () {

	try {
		var jquery_beds_baths_sqft = $(".zsg-content-header.addr h3 span");
		var beds = numeral(jquery_beds_baths_sqft.eq(1).text().split(' ')[0]).value();
		var baths = numeral(jquery_beds_baths_sqft.eq(3).text().split(' ')[0]).value();
		var sqft = numeral(jquery_beds_baths_sqft.eq(5).text().split(' ')[0]).value();

		return {
			beds: beds,
			baths: baths,
			sqft: sqft
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			beds: '',
			baths: '',
			sqft: ''
		}
	}
}
