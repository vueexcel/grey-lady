function get_listing_information_zillow_sale_2 () {

	var listing_information_to_return = $.extend(true, {}, return_empty_object() );

	listing_information_to_return.source = getSourceObject('zillow');
	listing_information_to_return.details.purchaseType = 'sell';
	listing_information_to_return.details.propertyType = tryToGetFromPage("$('.ds-home-fact-label:contains(\"Type\")').parent().find('span').eq(1).text()");

	//location
	listing_information_to_return.details.location = getZillowLocationObjectSale_v2();
	listing_information_to_return.details.location.CountyOrParish = '';


	//beds, baths and livingArea, year build
	listing_information_to_return.details.beds = tryToGetFromPage('numeral($(".ds-bed-bath-living-area").eq(0).find("span").eq(0).text()).value()');
	listing_information_to_return.details.baths = tryToGetFromPage('numeral($(".ds-bed-bath-living-area").eq(1).find("span").eq(0).text()).value()');
	listing_information_to_return.details.LivingArea = tryToGetFromPage('numeral($(".ds-bed-bath-living-area").eq(2).find("span").eq(0).text()).value()');
	listing_information_to_return.details.LivingAreaUnits = 'sqft';
	listing_information_to_return.details.YearBuilt = tryToGetFromPage("numeral($('.ds-home-fact-label:contains(\"Year Built\")').parent().find('span').eq(1).text()).value()");
	listing_information_to_return.details.PublicRemarks = tryToGetFromPage('$(".character-count-truncated").text()');

	//price in it's various forms.
	var price = tryToGetFromPage('numeral($(".ds-price").find("span.ds-value").eq(0).text()).value()');
	listing_information_to_return.details.price = price;
	listing_information_to_return.details.displayPrice = formatCurrency(price, 0);

	var lot_in_sqft = tryToGetFromPage("numeral($('.ds-home-fact-label:contains(\"Lot\")').parent().find('span').eq(1).text()).value()");
	listing_information_to_return.details.LotSizeSquareFeet = lot_in_sqft;
	listing_information_to_return.details.LotSizeAcres = convertSquareFeetToAcres(lot_in_sqft);

	listing_information_to_return.details.propertyTax = tryToGetFromPage("numeral($('span:contains(\"Property taxes\")').parent().find('span').eq(1).text()).value() * 12");
	listing_information_to_return.details.propertyTaxFrequency = 'annual';

	var agentObject = getZillowAgentObjectSale_v2()
	listing_information_to_return.details.ListAgentFirstName = agentObject.first;
	listing_information_to_return.details.ListAgentLastName = agentObject.last;
	listing_information_to_return.details.ListAgentPreferredPhone = agentObject.phone;
	listing_information_to_return.details.ListAgentPreferredEmail = agentObject.email;

	listing_information_to_return.details.AssociationFee = tryToGetFromPage("numeral($('.ds-home-fact-label:contains(\"Hoa\")').parent().find('span').eq(1).text()).value()");
	listing_information_to_return.details.AssociationFeeFrequency = 'month';

	return listing_information_to_return;

}



function getZillowLocationObjectSale_v2 () {
	try {

		var address = tryToGetFromPage('$(".ds-address-container").find("span").eq(0).text()');
		
		var city_state_zip = tryToGetFromPage('$(".ds-address-container").find("span").eq(1).text()');		
		var city = city_state_zip.split(',')[0];
		var state_zip = $.trim(city_state_zip.split(',')[1]);
		var state = state_zip.split(' ')[0];
		var zip = state_zip.split(' ')[1];

		return {
			address: address,
			city: city,
			state: state,
			zip: zip
		}

	} catch ( error ) {

		log_parsing_error(error);
		return false;
	}
}

function getZillowAgentObjectSale_v2 () {

	try {
		var firstName = '';
		var lastName = '';
		var phone = '';
		var email = '';

		

		var fullName = tryToGetFromPage('$(".home-details-listing-provided-by").find("span.listing-field").eq(0).text()');

		firstName = fullName.split(' ')[0];
		lastName = fullName.split(' ')[1];
		phone = $.trim(tryToGetFromPage('$(".home-details-listing-provided-by").find("span.listing-field").eq(2).text()'));

		return {
			first: firstName,
			last: lastName,
			phone: phone,
			email: email
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			first: '',
			last: '',
			phone: '',
			email: ''
		}
	}

}