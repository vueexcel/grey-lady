function getZillowAgentObjectSale () {

	try {
		var firstName = '';
		var lastName = '';
		var phone = '';
		var email = '';

		var jquery_agent_section = $('h2:contains(\"Listing Agent\")').parent().find("div.cf-amdl-sig-info span");
		var fullName = jquery_agent_section.eq(0).text();

		firstName = fullName.split(' ')[0];
		lastName = fullName.split(' ')[1];
		phone = $.trim(jquery_agent_section.eq(3).text());

		return {
			first: firstName,
			last: lastName,
			phone: phone,
			email: email
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			first: '',
			last: '',
			phone: '',
			email: ''
		}
	}

}
function getZillowBedsBathSqftSale () {

	try {
		var jquery_beds_baths_sqft = $(".hdp-home-header-st-addr").parent().parent().find("h3 span");
		var beds = numeral(jquery_beds_baths_sqft.eq(1).text().split(' ')[0]).value();
		var baths = numeral(jquery_beds_baths_sqft.eq(3).text().split(' ')[0]).value();
		var sqft = numeral(jquery_beds_baths_sqft.eq(5).text().split(' ')[0]).value();

		return {
			beds: beds,
			baths: baths,
			sqft: sqft
		}

	} catch ( error ) {

		log_parsing_error(error);
		return {
			beds: '',
			baths: '',
			sqft: ''
		}
	}
}
function getZillowLocationObjectSale () {
	try {

		var address = tryToGetFromPage('$(".hdp-home-header-st-addr").text()');
		var city_state_zip = tryToGetFromPage('$(".hdp-home-header-st-addr").parent().find("div").eq(1).text()');
		
		var city = city_state_zip.split(',')[0];
		var state_zip = $.trim(city_state_zip.split(',')[1]);
		var state = state_zip.split(' ')[0];
		var zip = state_zip.split(' ')[1];

		return {
			address: address,
			city: city,
			state: state,
			zip: zip
		}

	} catch ( error ) {

		log_parsing_error(error);
		return false;
	}
}