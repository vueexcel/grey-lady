
//This function determines what reader version to use based on what element is on the page. 
//I took this approach becaue it appears Zillow does a lot of A/B testing. Good for them. 
//makes keeping track of these readers a nightmare.
function getZillowReaderVersion () {

	var element_for_sale = "$('.home-details-price-area').find('.price .value').text()";
	var element_for_sale_2 = "$('.ds-status-details').text()";
	var element_for_rent = "$('#home-value-wrapper').find('.home-summary-row').text()";
	var element_for_rent_2 = tryToGetFromPage("$('span.ds-status-details').eq(0).text()");

	console.log(element_for_rent_2);

	if ( tryToGetFromPage(element_for_sale) ) {
		return 'sale_1';
	} else if ( tryToGetFromPage(element_for_rent) ) {
		return 'rent_1';
	} else if ( element_for_rent_2.indexOf('rent') > -1 ) {
		return 'rent_2';
	} else if ( tryToGetFromPage(element_for_sale_2) ) {
		return 'sale_2';
	} else {
		return 'none';
	}
}


//We're using the readerVersion method to figure out what reader to use. 
//tpyically readers are in their own file, in the sites specific reader directory.
function get_listing_information_zillow () {

	switch ( getZillowReaderVersion() ) {
		case 'sale_1':
			debug('Using Zillows sale_1 or rent_1 reader', 4);
			return get_listing_information_zillow_sale_and_rent();
		break;
		case 'rent_1':
			debug('Using Zillows rent_1 reader', 4);
			return get_listing_information_zillow_sale_and_rent();
		break;
		case 'sale_2':
			debug('Using Zillows sale_2 reader', 4);
			return get_listing_information_zillow_sale_2();
		break;
		case 'rent_2':
			debug('Using Zillows rent_2 reader', 4);
			return get_listing_information_zillow_rent_2();
		break;
		case 'none':
		default:
			debug('No Zillow reader found... need to create a new one', 4);
			return {};
		break;
	}

}




/*	

These are util functions and I'll document them later. 

*/

function isZillowPDPloaded () {

	//for rent and for sale listings have different DOM structures for displaying their rent. 
	//need to look for both of them. 
	var element_for_sale = "$('.home-details-price-area').find('.price .value').text()";
	var element_for_sale_2 = "$('.ds-status-details').text()";
	var element_for_rent = "$('#home-value-wrapper').find('.home-summary-row').text()";

	if ( tryToGetFromPage(element_for_sale) || tryToGetFromPage(element_for_rent) || tryToGetFromPage(element_for_sale_2) ) {
		return true;
	} else {
		debug('isZillowPDPloaded thinks this is not a pdp', 4)
		return false;
	}

}
function isZillow() {
	if ( (window.location.href.indexOf("zillow.com") > -1) ) {
		debug('This is zillow', 2);
		return true;
	} else {
		return false;
	}
}

