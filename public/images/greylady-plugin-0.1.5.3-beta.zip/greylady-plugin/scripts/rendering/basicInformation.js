function renderAddress() {

	// var address = '<a target=_blank href="' + config.grey_lady_base + '/listing/' + api_listing_information.id + '">' + api_listing_information.details.location.address + '</a>';
	// var city = '<a target=_blank href="' + config.grey_lady_base + '/explore/?town=' + api_listing_information.details.location.city + '">' + $.trim(api_listing_information.details.location.city)  + '</a>';
	// var state = '<a target=_blank href="' + config.grey_lady_base + '/explore/?stateAbbreviation=' + api_listing_information.details.location.state + '">' + api_listing_information.details.location.state + '</a>';
	// var zip = '<a target=_blank href="' + config.grey_lady_base + '/explore/?zip=' + api_listing_information.details.location.zip + '">' + api_listing_information.details.location.zip + '</a>';


	var address = api_listing_information.details.location.address;
	var city = $.trim(api_listing_information.details.location.city);
	var state = api_listing_information.details.location.state;
	var zip = api_listing_information.details.location.zip;

 	$('#grey-lady-container #address').html( address );
 	$('#grey-lady-container #city').html( city );
 	$('#grey-lady-container #state').html( state );
 	$('#grey-lady-container #zip').html( zip );

  	$('#grey-lady-close').bind('click', function (event) {
  		event.preventDefault();
  		closeGreylady();
  	});

  	$('#grey-lady-logout').bind('click', function () {
  		removeGreyLadyAppToken();
  	});
}

function renderBasicInformation () {
	var financial_information_html = '';
	
	financial_information_html += '<span>'+ translatePurchaseType(api_listing_information.details.purchaseType) + ': </span>';
	financial_information_html += '<span>'+ api_listing_information.details.propertyType + ' - </span>';
	financial_information_html += '<span>'+ api_listing_information.details.beds + ' beds, </span>';
	financial_information_html += '<span>'+ api_listing_information.details.baths + ' baths, </span>';
	financial_information_html += '<span>'+ abbreviateNumber(api_listing_information.details.livingArea, 'all') + '/' + api_listing_information.details.livingAreaUnits + ' </span>';
	
	document.getElementById('financial-information').innerHTML = financial_information_html;	
}

function translatePurchaseType (purchaseType) {
	var translatedPurchaseType = '';

	switch (purchaseType) {
		case 'sell':
			translatedPurchaseType = 'For Sale';
		break;
		case 'rent':
			translatedPurchaseType = 'For Rent';
		break;
		default:
			translatedPurchaseType = 'Couldnt translate';
		break;
	}

	return translatedPurchaseType;
}