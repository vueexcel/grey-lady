function show500RequestFailedScreen () {

	var h3message = '500 Error occurred';
	var content = '';
	content += '<p>This happens when the request back to the server returns an error. There are three reasons this could happens:</p>';
	content += '<ul>'
	content += '<li>The server is down.</li>'
	content += '<li>There was an invalid request made and a hard error is returned.</li>'
	content += '<li>You were logged out and need to log back in.</li>'
	content += '<li>There was a browser update which requires an update to the plugin</li>'
	content += '</ul>'
	content += '<p>Try refreshing the page. If it happens again, then please report the error.</p>';
	content += '<p class="row"></p>';

	showMessageScreen(h3message, content);

}

function showAuthErrorScreen () {
	
	var h3message = 'Please Log into the APP';
	var content = '';
	content += '<p>You need to re-login to the app.</p>';
	content += '<a target=_blank href="https://app.greyladyproject.com/login" type="submit" class="btn btn-primary btn-block btn-flat">Go to Login page</a>';
	content += '<p>Then refresh this page once you have logged in.</p>';
	content += '<p class="row"></p>';

	showMessageScreen(h3message, content);
}

function showUnknownError () {
	var h3message = 'Unknown Error';
	var content = '';
	content += '<p>Please let the plugin creator know ASAP</p>';
	content += '<p class="row"></p>';

	showMessageScreen(h3message, content);
} 

function showUpdateVersionScreen () {

	var h3message = 'New Version Available';
	var content = '';
	content += '<a target=_blank href="' + greylady_newest_plugin_version.download_link + '" type="submit" class="btn btn-primary btn-block btn-flat">Download New Version</a>';
	content += '<p class="row"></p>';
	content += '<p>Or sometimes you need to refresh the page. If this still shows, then theres most likely a new version available.</p>';

	showMessageScreen(h3message, content);	
	
}


function showMessageScreen ( h3Message, content ) {
	var sign_in_form_html = '';
	
	sign_in_form_html += '<div id="NewVersionAvailable">';
	sign_in_form_html += '<div class="login-box">';
	sign_in_form_html += '<div class="login-logo">';
	sign_in_form_html += '<b>Grey</b>Lady';
	sign_in_form_html += '</div>';
	sign_in_form_html += '<div class="login-box-body">';
	sign_in_form_html += '<h3 class="login-box-msg">'+h3Message+'</h3>';
	sign_in_form_html += content;
	sign_in_form_html += '</div>';
	sign_in_form_html += '</div>';

	document.getElementById('greyladycontainer').innerHTML += sign_in_form_html;	
}