function renderFinancials () {

	if (	api_listing_information &&
		 	api_listing_information.calculated_fields[0] && 
		 	api_listing_information.calculated_fields[0].settings_used && 
		 	api_listing_information.calculated_fields[0].settings_used.missing_data &&
		 	api_listing_information.calculated_fields[0].settings_used.missing_data.rentals_needed <= 0
	){

		renderQuickFinancialStats();
		renderFinancialOverview();
		renderPandL();
		renderSettings();

	} else {

		showNotEnoughFinancialData();

	}

	
}

function renderFinancialOverview () {

	var financial_information_html = '';

	if (api_listing_information.calculated_fields[0]) {
		var financial = api_listing_information.calculated_fields[0].financial_information;
		var mortgage = api_listing_information.calculated_fields[0].mortgage_information;
		var operating = api_listing_information.calculated_fields[0].operating_profit_and_loss.monthly;
		var settings = api_listing_information.calculated_fields[0].settings_used;
		
		financial_information_html += '<ul>';
		financial_information_html += '<li><b>Downpayment: </b>' + accounting.formatMoney(mortgage.downpayment, "$", 0) + '</li>';
		financial_information_html += '<li><b>Rent: </b>' + accounting.formatMoney(operating.revenue, "$", 0) + '</li>';
		financial_information_html += '<li><b>Mortgage Payment: </b>' + accounting.formatMoney(mortgage.monthly.payment, "$", 0) + '</li>';
		financial_information_html += '<li><b>Cap Rate: </b>' + formatPercentage(financial.cap_rate) + '</li>';
		financial_information_html += '<li><b>Cash on Cash: </b>' + formatPercentage(financial.cash_on_cash) + '</li>';
		financial_information_html += '<li><b>Rent to value: </b>' + formatPercentage(financial.rent_to_value) + '</li>';
		financial_information_html += '<li><b>Debt Coverate Ratio: </b>' + formatPercentage(financial.debt_coverage_ratio) + '</li>';
		financial_information_html += '</ul>';

	} else {
		financial_information_html += '<p>No overview available...</p>';		
	}

	

	$('#no-zip-available').hide();
	document.getElementById('financial-overview').innerHTML = financial_information_html;
}

function renderPandL () {

	var financial_information_html = '';

	if (api_listing_information.calculated_fields[0]) {

		var financial = api_listing_information.calculated_fields[0].financial_information;
		var mortgage = api_listing_information.calculated_fields[0].mortgage_information;
		var operating = api_listing_information.calculated_fields[0].operating_profit_and_loss.monthly;
		var settings = api_listing_information.calculated_fields[0].settings_used;
		
		financial_information_html += '<ul>';
		financial_information_html += '<li><b>Revenue: </b>' + accounting.formatMoney(operating.revenue, "$", 0) + '</li>';
		financial_information_html += '<li><b>Loss to Vacancy: </b>' + accounting.formatMoney(operating.loss_to_vacancy, "$", 0) + '</li>';
		financial_information_html += '<li><b>Operating Income: </b>' + accounting.formatMoney(operating.operating_income, "$", 0) + '</li>';
		financial_information_html += '<li><b>Operating Expense: </b>' + accounting.formatMoney(operating.operating_expenses, "$", 0) + '</li>';
		financial_information_html += '<li><b>Net Operating Income: </b>' + accounting.formatMoney(operating.net_operating_income, "$", 0) + '</li>';
		financial_information_html += '<li><b>Mortgage Payment: </b>' + accounting.formatMoney(operating.mortgage_payment, "$", 0) + '</li>';
		financial_information_html += '<li><b>Cash Profit: </b>' + accounting.formatMoney(operating.cash_profit, "$", 0) + '</li>';
		financial_information_html += '</ul>';

	} else {
		financial_information_html += '<p>No P&L information available...</p>';		
	}

	document.getElementById('profit_and_loss').innerHTML = financial_information_html;

}
function renderSettings () {

	var financial_information_html = '';

	if (api_listing_information.calculated_fields[0]) {

		var settings = api_listing_information.calculated_fields[0].settings_used;
		
		financial_information_html += '<ul>';
		financial_information_html += '<li><b>Date Calculated: </b>' + settings.date_calculated + '</li>';
		financial_information_html += '<li><b>Downpayment: </b>' + formatPercentage(settings.downpayment) + '</li>';
		financial_information_html += '<li><b>Operational Expenses: </b>' + formatPercentage(settings.operational_expenses) + '</li>';
		financial_information_html += '<li><b>Vacancy: </b>' + formatPercentage(settings.vacancy_rate) + '</li>';

		financial_information_html += '</ul>';
	} else {
		financial_information_html += '<p>No settings information available...</p>';		
	}

	document.getElementById('settings').innerHTML = financial_information_html;

}

function showNotEnoughFinancialData () {

	var html = '';	
  	var base_zillow_url = 'https://zillow.com';
  	var base_trulia_url = 'https://trulia.com';
  	var base_realtor_url = 'https://realtor.com';


	if (api_listing_information.details.purchaseType == 'rent') {

		modifyInterfaceForRental();

	} else if (api_listing_information.calculated_fields &&
		api_listing_information.calculated_fields[0] &&
		api_listing_information.calculated_fields[0].settings_used
		) {

			var missing_data = api_listing_information.calculated_fields[0].settings_used.missing_data;
			var details = api_listing_information.details;
			var zip = details.location.zip;
			var beds = details.beds;

			html += "<h2>Not enough rental data to calculate financials</h2>";
			html += "<h3>Add rentals to the DB by viewing them here:</h3>";
			html += "<ul>";
			html += "<li><a target=_blank href='" + base_zillow_url + "/homes/for_rent/" + zip + "/" + beds + "-_beds/" + "'>Zillow - "+zip + ' + ' + beds +' beds + Rentals'+"</a></li>";
			html += "<li><a target=_blank href='" + base_trulia_url + "/for_rent/" + zip + "_zip/" + beds + "_beds/" + "'>Trulia - "+zip + ' + ' + beds +' beds + Rentals'+"</a></li>";
			html += "<li><a target=_blank href='" + base_realtor_url + "/apartments/" + zip + "/beds-" + beds + "-" + beds + "'>Realtor - "+zip + ' + ' + beds +' beds + Rentals'+"</a></li>";
			html += "</ul>";
			html += "<h3>Listings in database for " + beds + " beds in " + zip + ':</h3>';
			html += "<ul>";
			html += "<li> For rent: (Have) " + missing_data.rentals_have + " / (Need) "+missing_data.rentals_needed+" | <a target=_Blank href='//app.greyladyproject.com/listings?zip="+zip+"&minBed="+beds+"&maxBed="+beds+"&type=rent'>Search in App</a></li>";
			html += "<li> For Sale: (Have) " + missing_data.sales_have + " / (Need) "+missing_data.sales_needed+" | <a target=_Blank href='//app.greyladyproject.com/listings?zip="+zip+"&minBed="+beds+"&maxBed="+beds+"&type=sell'>Search in App</a></li>";
			html += "</ul>";

			$('#listing-financials-section').remove();
			$('#greylady-financial-overview').html(html);

	} else {
			$('#greylady-financial-overview').html('<p>Something went wrong</p>');		
	}


}

function modifyInterfaceForRental () {
	$('#greylady-financial-wrapper').remove();
	$('#listing-financials-section').remove();
} 