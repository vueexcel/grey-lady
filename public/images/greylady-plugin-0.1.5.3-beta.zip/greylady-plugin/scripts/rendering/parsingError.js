function enoughListingInformation (listing_information) {

	debug('**********************************************', 1);
	debug('Listing Information pulled from page by JS: ', 1);
	debug(listing_information, 1)
	

	// Checking for attributes of the listing that are empty
	var listing_check = checkListingObject( listing_information );

	//then show the overlay or not.
	if (listing_check.not_enough_listing_information) {

		debug('Some information is missing:', 1);
		debug(listing_check.missing_listing_information, 1)
		debug('**********************************************', 1);

		showParsingErrorOverlay(listing_check.missing_listing_information);
		reportParsingErrorToGreylady();

		return false;		
	} else {
		return true;
	}

	

}

function checkListingObject ( listing_information ) {

	var response = {};
	response.not_enough_listing_information = false
	response.missing_listing_information = [];

	if (!listing_information) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('No listing data from the page. Is this a supported type of property?');
		return response;
	}


	if (!listing_information.details.location.address) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Address is empty');
	}

	if (!listing_information.details.location.zip) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Zip is empty');
	}

	if (!listing_information.details.beds) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Beds is empty');
	}

	if (!listing_information.details.baths) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Baths is empty');
	}

	if (!listing_information.details.price) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Price is empty');
	}

	if (!listing_information.details.purchaseType) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Purchase Type is empty');
	}

	if (!listing_information.source.source) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Source is empty');
	}


	// Checking that values generally make sense

	if (listing_information.details.beds > 40) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Beds is reading as ' + listing_information.details.beds + ' - cannot be over 40');
	}

	if (listing_information.details.beds < 1) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Beds is reading as ' + listing_information.details.beds + ' - cannot be less than 1.');
	}

	if (listing_information.details.baths > 20) {
		response.not_enough_listing_information = true;
		response.missing_listing_information.push('Baths is reading as ' + listing_information.details.baths + ' - cannot be over 20');
	}

	return response;
}

function showParsingErrorOverlay (missing_listing_information) {

	var html = '';
	
	html += '<div id="NewVersionAvailable">';
	html += '<div class="login-box">';
	html += '<div class="login-logo">';
	html += '<b>Grey</b>Lady';
	html += '</div>';
	html += '<div class="login-box-body">';
	html += '<h3 class="login-box-msg">Not enough information to load this listing...</h3>';
	html += '<p class="login-box-msg">This error has automatically been reported. The plugin will close in 20 seconds.</p>';

	if (missing_listing_information.length !== 0) {
		html += '<p class="login-box-msg">Here is the information that is missing:</p>';
		html += '<ul>';
			for (var i = missing_listing_information.length - 1; i >= 0; i--) {
				html += '<li>' + missing_listing_information[i] + '</li>';
			}
		html += '</ul>';

		html += '<p class="login-box-msg">This likely shouldnt be happening. And probably means the reader is pulling incorrect information from the page. Report this bug.</p>';

	}

	
	html += '</div>';
	html += '</div>';

	document.getElementById('greyladycontainer').innerHTML += html;	
}
