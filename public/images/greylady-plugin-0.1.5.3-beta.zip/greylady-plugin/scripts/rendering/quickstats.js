function renderQuickFinancialStats () {

	var html = '';	

	if (api_listing_information && api_listing_information.calculated_fields && api_listing_information.calculated_fields[0] && api_listing_information.calculated_fields[0].financial_information) {
		var financial_info = api_listing_information.calculated_fields[0].financial_information;
		var operating_info = api_listing_information.calculated_fields[0].operating_profit_and_loss.monthly;
		

		html += buildQuickStatItem(formatPercentage(financial_info.cap_rate), 'Cap');
		html += buildQuickStatItem(formatPercentage(financial_info.cash_on_cash), 'CoC');
		html += buildQuickStatItem(accounting.formatMoney(operating_info.cash_profit, "$", 0), 'Cash');
	} else {
		html += '<p>No quick stats available...</p>';		
	}

	$('#greylady-financial-overview').html(html);
}