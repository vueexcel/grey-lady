function isUpdateAvailable() {

	switch ( isCurrentVersionLatest() ) {

		case 'NoUpdate':
			return false;
			break;

		case 'updateNeeded':
			showUpdateVersionScreen();
			return true;
			break;

		case 'authError':
			showAuthErrorScreen();
			return true;
			break;

		case 'unknownError':
		default: 
			showUnknownError();
			return true;
			break;
	}
}

function isCurrentVersionLatest() {

	var manifestData = chrome.runtime.getManifest();

	debug('===================================', 1);
	debug('API Version: ', 1);
	debug(greylady_newest_plugin_version.version, 1);
	debug('Manifest Version: ', 1);
	debug(manifestData.version, 1);
	debug('===================================', 1);

	if (greylady_newest_plugin_version.version == '' || greylady_newest_plugin_version.version == null) {
		debug('authError', 1);
		return 'authError';
	} else if ( greylady_newest_plugin_version.version !== manifestData.version ) {
		debug('updateNeeded', 1);
		return 'updateNeeded';
	} else if ( greylady_newest_plugin_version.version == manifestData.version ) {
		debug('NoUpdate', 1);
		return 'NoUpdate';
	} else {
		debug('unknownError', 1);
		return 'unknownError';
	}
}