function renderZipStats () {

	renderZipOverview();
	renderZipTopListings();
	renderZipIncomeStats();
	renderZipHousingStats();
	
}

function renderZipOverview() {
	
	var by_beds = zip_information.calculated_fields.by_beds;
	var zip_table_html = '';

	zip_table_html += '<table class="table table-hover" style="width: 400px">\
	            <thead>\
	                <tr>\
	                    <th>Bed</th>\
	                    <th>Price</th>\
	                    <th>Sqft</th>\
	                    <th>Cap</th>\
	                    <th>Rent</th>\
	                    <th>#</th>\
	                </tr>\
	            </thead>\
            	<tbody>';

	// accounting.formatMoney(operating.revenue, "$", 0)
    for (beds in by_beds) {
    	zip_table_html += '<tr>';
			zip_table_html += '<td> <a target="_blank" href="https://app.greyladyproject.com/listings?zip='+api_listing_information.details.location.zip+'&minBed='+beds+'&maxBed='+beds+'">'+beds+'</td>';
			zip_table_html += '<td>'+abbreviateCurrency(by_beds[beds].average_price)+'</td>';
			zip_table_html += '<td>'+abbreviateNumber(by_beds[beds].average_livingArea, 1)+'</td>';
			zip_table_html += '<td>'+formatPercentage(by_beds[beds].average_cap_rate)+'</td>';
			zip_table_html += '<td> <a target="_blank" href="https://app.greyladyproject.com/listings?zip='+api_listing_information.details.location.zip+'&minBed='+beds+'&maxBed='+beds+'&type=rent">'+abbreviateCurrency(by_beds[beds].average_revenue, 1)+'</a></td>';
			zip_table_html += '<td> <a target="_blank" href="https://app.greyladyproject.com/listings?zip='+api_listing_information.details.location.zip+'&minBed='+beds+'&maxBed='+beds+'&type=sell">'+by_beds[beds].number_of_listings+'</a></td>';
		zip_table_html += '</tr>';
    }

    zip_table_html += '</tbody>';
    zip_table_html += '</table>';

	document.getElementById('zip-summary').innerHTML = zip_table_html;
}

function renderZipTopListings() {
	
	var best_cap_listings = zip_information.calculated_fields.best_listings.by_cap_rate;
	var best_cash_listings = zip_information.calculated_fields.best_listings.by_cash_on_cash;
	
	var zip_table_html = '';
	zip_table_html += '<h3>Best Cap Rate</h3>';

	zip_table_html += '<table class="table table-hover" style="width: 400px">\
	            <thead>\
	                <tr>\
	                    <th>Address</th>\
	                    <th>Beds</th>\
	                    <th>Cap</th>\
	                </tr>\
	            </thead>\
            	<tbody>';

	// accounting.formatMoney(operating.revenue, "$", 0)
    for (item in best_cap_listings) {
    	zip_table_html += '<tr>';
			zip_table_html += '<td><a href="'+config.grey_lady_base + '/listing/' + best_cap_listings[item].id + '" target=_blank>'+best_cap_listings[item].address+'</a></td>';
			zip_table_html += '<td>'+best_cap_listings[item].beds+'</td>';
			zip_table_html += '<td>'+formatPercentage(best_cap_listings[item].cap_rate)+'</td>';
			// zip_table_html += '<td>'+formatPercentage(best_cap_listings[item].cap_rate)+'</td>';
		zip_table_html += '</tr>';
    }

    zip_table_html += '</tbody>';
    zip_table_html += '</table>';

    zip_table_html += '<h3>Best CoC Rate</h3>';

    zip_table_html += '<table class="table table-hover" style="width: 400px">\
	            <thead>\
	                <tr>\
	                    <th>Address</th>\
	                    <th>Beds</th>\
	                    <th>Cap</th>\
	                </tr>\
	            </thead>\
            	<tbody>';

	// accounting.formatMoney(operating.revenue, "$", 0)
    for (item in best_cash_listings) {
    	zip_table_html += '<tr>';
			zip_table_html += '<td><a href="'+config.grey_lady_base + '/listing/' + best_cash_listings[item].id + '" target=_blank>'+best_cash_listings[item].address+'</a></td>';
			zip_table_html += '<td>'+best_cash_listings[item].beds+'</td>';
			zip_table_html += '<td>'+formatPercentage(best_cash_listings[item].cash_on_cash)+'</td>';
		zip_table_html += '</tr>';
    }

    zip_table_html += '</tbody>';
    zip_table_html += '</table>';

	document.getElementById('zip-top-listings').innerHTML = zip_table_html;
}
function renderZipIncomeStats() {
	var income = zip_information.details.income;
	var zip_table_html = '';
	zip_table_html += '<ul>';

	for (key in income) {
		zip_table_html += '<li>' + key + ': ' + income[key] + '<li>';	
	}

	zip_table_html += '</ul>';

	document.getElementById('zip-income').innerHTML = zip_table_html;
}
function renderZipHousingStats() {
	var housing = zip_information.details.housing;

	var zip_table_html = '';

	if ( !Array.isArray(housing) || !housing.length ) {

		zip_table_html += '<ul>';

		for (key in housing) {
			zip_table_html += '<li>' + key + ': ' + housing[key] + '<li>';	
		}

		zip_table_html += '</ul>';

	} else {

		zip_table_html = 'No housing data for this zip code';

	}

	document.getElementById('zip-housing').innerHTML = zip_table_html;
}