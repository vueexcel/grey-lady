function showSuccessMessage (header) {
	$('#listing-loaded-status').html('<svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/><path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/></svg>');
}

function showFailMessage (header) {
	$('#message-area').html('<div class="callout callout-fail"><p>'+header+'</p></div>').delay(500).fadeOut('slow');
}
function formatPercentage(number_to_format) {
	// return " " + (Number(Math.round((number_to_format * 100)+'e3')+'e-3')) + "%";
	return " " + numeral(number_to_format).format('0.0%');
}
function buildQuickStatItem (number, label) {
	var html = ''
	html += '<div class="stat-item">';
	html += '<div class="description-block">';
	html += '<h5 class="description-header">'+number+'</h5>';
	html += '<span class="description-text">'+label+'</span>';
	html += '</div>';
	html += '</div>';
	return html;
}
function formatCurrency(value, digits = 0) {
	return '$' + abbreviateNumber(value, digits);
}
function abbreviateCurrency(value, digits = 0) {
	return '$' + abbreviateNumber(value, digits);
}
function abbreviateNumber(value, digits = 0) {
    
    if (digits == 0) {
    	return numeral(value).format('0a');	
    } else if (digits == 'all') {
    	return numeral(value).format();	
    } else {
		return numeral(value).format('0.0a');	
    }
}
function convertSquareFeetToAcres (square_feet) {
	var acres = numeral(square_feet).value() * 0.000023;
	return numeral(acres).format('0.00');
}

function debug(value, debug_level = 1 ) {
	if ( debug && ( logging_level >= debug_level ) ) {
		console.log(value);
	}
}


function shouldOpenGreyLady () {

	if ( onSupportedPDP() && isGreyLadyOpen() ) {
		return 'nothing';
	} else if ( !onSupportedPDP() && !isGreyLadyOpen()  ) {
		return 'nothing';
	} else if ( !onSupportedPDP() && isGreyLadyOpen() ) {
		return 'close';
	} else if ( onSupportedPDP() && !isGreyLadyOpen() ) {
		return 'open';
	} else {
		return 'nothing';
	}
	
}
function isGreyLadyOpen () {
	if (greylady_open) {
		debug('Greylady is open..', 10);	
	} else {
		debug('Greylady is closed..', 10);	
	}
	return greylady_open;
}
function onSupportedPDP () {

	if ( (window.location.href.indexOf("realtor.com") > -1) && (window.location.href.indexOf("realestateandhomes-detail") > -1) ) {
		debug('On a realtor.com pdp', 10);
		return true;
	} else if ( (window.location.href.indexOf("zillow.com") > -1) && (window.location.href.indexOf("_zpid") > -1) && isZillowPDPloaded()  ) {
		debug('On a zillow.com pdp', 10);
		return true;
	} else {
		debug('onSupportedPDP is returning false', 10);
		return false;
	}
}

function isRealtorPDPloaded () {

	var element = '$("#aj-qv-sec-property-header").find(".price span").text()';

	if ( tryToGetFromPage(element) ) {
		return true;
	} else {
		return false;
	}
	
}
function isRealtor() {
	if ( (window.location.href.indexOf("realtor.com") > -1) ) {
		debug('This is realtor', 2);
		return true;
	} else {
		return false;
	}
}